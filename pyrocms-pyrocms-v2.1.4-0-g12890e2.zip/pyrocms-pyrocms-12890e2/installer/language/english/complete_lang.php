<?php defined('BASEPATH') OR exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Congratulations';
$lang['intro_text']			= 'PyroCMS is now installed and ready to go! Please log into the admin panel with the following details.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Password';
$lang['show_password']		= 'Show Password?';
$lang['outro_text']			= 'Finally, <strong>delete the installer from your server</strong> as if you leave it here it can be used to hack your website.';

$lang['go_website']			= 'Go to Website';
$lang['go_control_panel']	= 'Go to Control Panel';

/* End of file complete_lang.php */