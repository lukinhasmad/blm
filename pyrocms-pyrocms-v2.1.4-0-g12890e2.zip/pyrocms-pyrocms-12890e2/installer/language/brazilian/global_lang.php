<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['intro']							=	'Introdução';
$lang['step1']							=	'1ª Etapa';
$lang['step2']							=	'2ª Etapa';
$lang['step3']							=	'3ª Etapa';
$lang['step4']							=	'4ª Etapa';
$lang['final']							=	'Última etapa';

$lang['installer.passwords_match']		= "As senhas coincidem.";
$lang['installer.passwords_dont_match']	= "As senhas não coincidem.";