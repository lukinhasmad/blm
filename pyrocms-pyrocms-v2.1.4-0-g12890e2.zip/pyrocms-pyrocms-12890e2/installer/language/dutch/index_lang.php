<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['header']		=	'Welkom';
$lang['thankyou']	=	'Bedankt dat u heeft gekozen voor PyroCMS!';
$lang['text']		=	'PyroCMS installeren is erg makkelijk, volg gewoon de stappen en berichten op het scherm. Mocht u problemen tegenkomen tijdens het installeren, maakt u zich dan geen zorgen: de installer zal u vertellen wat u moet doen om het op te lossen.';
$lang['step1'] 		= 	'Stap 1';
$lang['link']		= 	'Ga verder naar de volgende stap';

/* End of file index_lang.php */