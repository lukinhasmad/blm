<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['intro']	=	'Introduction';
$lang['step1']	=	'Étape #1';
$lang['step2']	=	'Étape #2';
$lang['step3']	=	'Étape #3';
$lang['step4']	=	'Étape #4';
$lang['final']	=	'Dernière étape';

$lang['installer.passwords_match']		= 'Les mots de passe correspondent.';
$lang['installer.passwords_dont_match']	= 'Les mots de passe ne correspondent pas.';