<?php defined('BASEPATH') or exit('No direct script access allowed');


$lang['header'] = 'Välkommen';
$lang['thankyou'] = 'Tack för att du väljer PyroCMS!';
$lang['text'] = 'Att installera PyroCMS är väldigt enkelt, följ bara instruktionerna i denna installtionsguide. Får du problem under installationen kommer installationsprogrammet att ge dig förslag på nödvändiga åtgärder.';
$lang['step1'] = 'Steg 1';
$lang['link'] = 'Fortsätt till steg ett';



/* End of file index_lang.php */  
/* Location: ./installer/language/english */ 