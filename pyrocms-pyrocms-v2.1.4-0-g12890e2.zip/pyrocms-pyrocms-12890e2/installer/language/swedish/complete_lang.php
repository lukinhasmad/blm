<?php defined('BASEPATH') or exit('No direct script access allowed');


$lang['congrats'] = 'Gratulerar';
$lang['intro_text'] = 'PyroCMS är nu installerat och redo att användas! Logga in och administrera webbplatsen med följande uppgifter.';
$lang['email'] = 'E-post';
$lang['password'] = 'Lösenord';
$lang['show_password'] = 'Visa lösenord';
$lang['outro_text'] = 'OBS, <strong>Radera mappen "installer" </strong> annars kan obehöriga ges tillträde till administrationsgränssnittet och sabotera din webbplats.';
$lang['go_website'] = 'Gå till webbplatsen';
$lang['go_control_panel'] = 'Gå till kontrollpanelen';



/* End of file complete_lang.php */  
/* Location: ./installer/language/english */ 