<?php defined('BASEPATH') OR exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Chúc mừng';
$lang['intro_text']			= 'PyroCMS đã được cài đặt thành công! Hãy đăng nhập vào trang quản trị với các thông tin sau.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Mật khẩu';
$lang['show_password']		= 'Show Password?'; #translate
$lang['outro_text']			= 'Cuối cùng, <strong>Hãy xóa thư mục installer trên máy chủ của bạn</strong>, nếu không website của bạn có thể bị tấn công.';

$lang['go_website']			= 'Xem website';
$lang['go_control_panel']	= 'Vào trang quản trị';

/* End of file complete_lang.php */