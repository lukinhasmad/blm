<!-- Welcome -->
<section class="title">
	<h3>{header}</h3>
</section>

<section class="item">
	<p>{thankyou}</p>

	<p>{text}</p>
	
	<a class="btn orange" id="next_step" href="<?php echo site_url('installer/step_1'); ?>" title="{link}">{step1}</a>
</section>