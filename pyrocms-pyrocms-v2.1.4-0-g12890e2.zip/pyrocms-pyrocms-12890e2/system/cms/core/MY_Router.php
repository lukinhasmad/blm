<?php (defined('BASEPATH')) OR exit('No direct script access allowed');
/**
 * The Router Handler Library.
 * 
 * @author PyroCMS Dev Team
 * @package PyroCMS\Core\Libraries 
 */
require APPPATH."libraries/MX/Router.php";

/**
 * Nothing to see here, move along.
 */
class MY_Router extends MX_Router {}