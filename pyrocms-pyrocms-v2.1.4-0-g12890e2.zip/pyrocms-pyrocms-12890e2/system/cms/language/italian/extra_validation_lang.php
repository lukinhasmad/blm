<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Il campo %s può contenere solo caratteri alfa-numerici, trattini in basso (underscores), punti e trattini.";
$lang['decimal']				= "Il campo %s può contenere solo numeri decimali.";
$lang['csrf_bad_token']			= "Token CSRF non valido";

/* End of file form_validation_lang.php */