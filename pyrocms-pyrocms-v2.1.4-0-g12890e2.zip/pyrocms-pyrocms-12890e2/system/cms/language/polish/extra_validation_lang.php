<?php

$lang['alpha_dot_dash']			= "Pole %s może zawierać tylko znaki alfanumeryczne, podkreślenie, kropkę i myślnik.";
$lang['decimal']				= "Pole %s może zawierać tylko liczbę dziesiętną.";
$lang['csrf_bad_token']			= "Nieprawidłowy token CSRF";

/* End of file form_validation_lang.php */